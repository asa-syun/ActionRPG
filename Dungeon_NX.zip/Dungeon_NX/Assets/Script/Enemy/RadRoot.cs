using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RadRoot : MonoBehaviour
{
    //�����ʒu
    private Vector3 startPosition;
    //�ړI�n
    [SerializeField] private Vector3 destination;

    [SerializeField] private Transform[] targets;

    [SerializeField] private int order = 0;

    public enum Route { inOrder, random }
    public Route route;


    void Start()
    {
        //�@�����ʒu��ݒ�
        startPosition = transform.position;
        SetDestination(transform.position);
    }

    public void CreateDestination()
    {
        if (route == Route.inOrder)
        {
            CreateInOrderDestination();
        }
        else if (route == Route.random)
        {
            CreateRandomDestination();
        }
    }

    //targets�ɐݒ肵�����Ԃɍ쐬
    private void CreateInOrderDestination()
    {
        if (order < targets.Length - 1)
        {
            order++;
            SetDestination(new Vector3(targets[order].transform.position.x, 0, targets[order].transform.position.z));
        }
        else
        {
            order = 0;
            SetDestination(new Vector3(targets[order].transform.position.x, 0, targets[order].transform.position.z));
        }
    }

    //�@targets���烉���_���ɍ쐬
    private void CreateRandomDestination()
    {
        int num = Random.Range(0, targets.Length);
        SetDestination(new Vector3(targets[num].transform.position.x, 0, targets[num].transform.position.z));
    }

    //�@�ړI�n�̐ݒ�
    public void SetDestination(Vector3 position)
    {
        destination = position;
    }

    //�@�ړI�n�̎擾
    public Vector3 GetDestination()
    {
        return destination;
    }
}
