using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerWalk : MonoBehaviour
{
	[Header("����")][SerializeField]private float speed = 4.5f;
	//�G���G�ꂽ�ꍇ�ɂ����삷�邽��public
	private bool Control = false;

	void Update()
    {
		
		if(Input.GetKeyDown(KeyCode.Space) && !Control)
		{ 
			Control = true;
			TextManager.instance.titleText.enabled = false;
			//�ŏ�����n�߂��\��
			TextManager.instance.startText.enabled = false;
		}

		if(Control)
        {
			Move();
		}

    }

     void Move()
    {

		
		if (Input.GetKey("up"))
		{
			transform.position += transform.forward * speed * Time.deltaTime;
		}
		if (Input.GetKey("down"))
		{
			transform.position -= transform.forward * speed * Time.deltaTime;
		}
		if (Input.GetKey("right"))
		{
			transform.position += transform.right * speed * Time.deltaTime;
		}
		if (Input.GetKey("left"))
		{
			transform.position -= transform.right * speed * Time.deltaTime;
		}
	}

	
}
